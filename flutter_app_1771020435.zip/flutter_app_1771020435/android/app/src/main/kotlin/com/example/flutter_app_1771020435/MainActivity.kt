package com.example.flutter_app_1771020435

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
