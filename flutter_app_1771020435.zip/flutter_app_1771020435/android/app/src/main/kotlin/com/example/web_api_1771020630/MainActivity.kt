package com.example.web_api_1771020630

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
