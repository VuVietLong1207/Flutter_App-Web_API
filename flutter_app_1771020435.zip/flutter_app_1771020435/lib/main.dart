import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'screens/home_screen.dart';
import 'screens/booking_screen.dart';
import 'screens/my_reservations_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Lưu ý: Điền đúng thông số từ Firebase Console của bạn vào đây
  await Firebase.initializeApp(
    options: const FirebaseOptions(
      apiKey: "AIzaSy...", 
      appId: "1:123456...", 
      messagingSenderId: "123456...",
      projectId: "flutterapp1771020435", 
      storageBucket: "your-app.appspot.com",
    ),
  );
  
  runApp(const RestaurantApp());
}

class RestaurantApp extends StatelessWidget {
  const RestaurantApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Restaurant App - 1771020435',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.orange, 
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.orange),
      ),
      home: const MainNavigation(),
    );
  }
}

// Lớp điều hướng chính để chứa các nút Đặt bàn, Đơn hàng
class MainNavigation extends StatefulWidget {
  const MainNavigation({super.key});

  @override
  State<MainNavigation> createState() => _MainNavigationState();
}

class _MainNavigationState extends State<MainNavigation> {
  int _selectedIndex = 0;
  
  // ID giả lập cho khách hàng (Trong thực tế sẽ lấy từ màn hình Login)
  final String testCustomerId = "CUSTOMER_001"; 

  late final List<Widget> _screens;

  @override
  void initState() {
    super.initState();
    _screens = [
      const HomeScreen(), // Màn hình thực đơn
      BookingScreen(customerId: testCustomerId), // Màn hình đặt bàn
      MyReservationsScreen(customerId: testCustomerId), // Màn hình đơn hàng
    ];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _screens[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: (index) => setState(() => _selectedIndex = index),
        selectedItemColor: Colors.orange,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.menu_book), label: 'Thực đơn'),
          BottomNavigationBarItem(icon: Icon(Icons.add_circle), label: 'Đặt bàn'),
          BottomNavigationBarItem(icon: Icon(Icons.history), label: 'Đơn của tôi'),
        ],
      ),
    );
  }
}