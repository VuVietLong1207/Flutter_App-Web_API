import 'package:flutter/material.dart';
import 'screens/login_screen.dart'; // Thêm folder 'screens/' vào trước tên file

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Quản lý Nhà hàng 1771020435',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const LoginScreen(), // Đặt màn hình Đăng nhập là mặc định
      debugShowCheckedModeBanner: false,
    );
  }
}