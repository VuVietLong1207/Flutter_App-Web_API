class MenuItem {
  final int id;
  final String name;
  final double price;
  final String? imageUrl;
  final bool isVegetarian;
  final bool isSpicy;
  final int preparationTime;

  MenuItem({
    required this.id,
    required this.name,
    required this.price,
    this.imageUrl,
    required this.isVegetarian,
    required this.isSpicy,
    required this.preparationTime,
  });

  factory MenuItem.fromJson(Map<String, dynamic> json) {
    return MenuItem(
      id: json['id'] ?? 0,
      name: json['name'] ?? '',
      // Sửa: Dùng (json['price'] ?? 0).toDouble() để tránh lỗi kiểu dữ liệu
      price: (json['price'] ?? 0).toDouble(),
      // Sửa các Key bên dưới từ snake_case sang camelCase
      imageUrl: json['imageUrl'], 
      isVegetarian: json['isVegetarian'] ?? false,
      isSpicy: json['isSpicy'] ?? false,
      preparationTime: json['preparationTime'] ?? 0, // Đã sửa để hiện đúng 15 phút
    );
  }
}