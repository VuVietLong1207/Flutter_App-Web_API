class MenuItemModel {
  final String id;
  final String name;
  final double price;
  final String imageUrl;
  final bool isAvailable;
  final bool isVegetarian;
  final bool isSpicy;
  final List<String> ingredients;

  MenuItemModel({
    required this.id, required this.name, required this.price,
    required this.imageUrl, required this.isAvailable,
    required this.isVegetarian, required this.isSpicy, required this.ingredients,
  });

  factory MenuItemModel.fromFirestore(Map<String, dynamic> data, String id) {
    return MenuItemModel(
      id: id,
      name: data['name'] ?? '',
      price: (data['price'] ?? 0).toDouble(),
      imageUrl: data['imageUrl'] ?? '',
      isAvailable: data['isAvailable'] ?? false,
      isVegetarian: data['isVegetarian'] ?? false,
      isSpicy: data['isSpicy'] ?? false,
      ingredients: List<String>.from(data['ingredients'] ?? []),
    );
  }
}