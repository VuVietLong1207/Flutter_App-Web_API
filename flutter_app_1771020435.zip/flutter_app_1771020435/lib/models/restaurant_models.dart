import 'package:cloud_firestore/cloud_firestore.dart';

class MenuItem {
  final String itemId;
  final String name;
  final double price;
  final bool isAvailable;
  final String category;

  MenuItem({
    required this.itemId, 
    required this.name, 
    required this.price, 
    required this.isAvailable,
    required this.category,
  });

  factory MenuItem.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return MenuItem(
      itemId: doc.id,
      name: data['name'] ?? '',
      price: (data['price'] ?? 0).toDouble(),
      isAvailable: data['isAvailable'] ?? true,
      category: data['category'] ?? '',
    );
  }
}

class Reservation {
  final String id;
  final DateTime date;
  final int guests;
  final String status;
  final double total;

  Reservation({
    required this.id, required this.date, 
    required this.guests, required this.status, required this.total
  });

  factory Reservation.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return Reservation(
      id: doc.id,
      date: (data['reservationDate'] as Timestamp).toDate(),
      guests: data['numberOfGuests'] ?? 0,
      status: data['status'] ?? 'pending',
      total: (data['total'] ?? 0).toDouble(),
    );
  }
}