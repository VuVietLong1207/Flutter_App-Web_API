import 'package:cloud_firestore/cloud_firestore.dart';

class MenuRepository {
  final CollectionReference _menu = FirebaseFirestore.instance.collection('menu_items');

  // Tìm kiếm trong name, description, ingredients [cite: 95]
  Future<List<DocumentSnapshot>> searchMenu(String query) async {
    // Lưu ý: Firestore không hỗ trợ tìm kiếm full-text trực tiếp tốt, 
    // thông thường sẽ lọc theo tên bắt đầu bằng query.
    var result = await _menu
        .where('name', isGreaterThanOrEqualTo: query)
        .where('name', isLessThanOrEqualTo: query + '\uf8ff')
        .get();
    return result.docs;
  }

  // Lọc theo Category, Chay, Cay [cite: 96, 97, 98, 99]
  Query filterMenu({String? category, bool? isVegetarian, bool? isSpicy}) {
    Query query = _menu;
    if (category != null) query = query.where('category', isEqualTo: category);
    if (isVegetarian != null) query = query.where('isVegetarian', isEqualTo: isVegetarian);
    if (isSpicy != null) query = query.where('isSpicy', isEqualTo: isSpicy);
    return query;
  }
}