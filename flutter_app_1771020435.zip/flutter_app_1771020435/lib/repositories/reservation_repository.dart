import 'package:cloud_firestore/cloud_firestore.dart';

class ReservationRepository {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  // 3.3.1: Đặt bàn mới
  Future<void> createReservation(String customerId, DateTime date, int guests, String requests) async {
    await _db.collection('reservations').add({
      'customerId': customerId,
      'reservationDate': Timestamp.fromDate(date),
      'numberOfGuests': guests,
      'specialRequests': requests,
      'status': 'pending',
      'orderItems': [],
      'subtotal': 0.0,
      'serviceCharge': 0.0,
      'total': 0.0,
      'paymentStatus': 'pending',
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  // 3.3.2: Thêm món vào đơn - ĐÃ SỬA LỖI THEO YÊU CẦU
  Future<void> addItemToReservation(String reservationId, String itemId, int quantity) async {
    // Lấy thông tin món ăn để kiểm tra isAvailable và lấy giá
    DocumentSnapshot itemDoc = await _db.collection('menu_items').doc(itemId).get();
    if (itemDoc['isAvailable'] == false) throw Exception("Món ăn đã hết!");

    double price = (itemDoc['price'] as num).toDouble();
    double itemSubtotal = price * quantity;

    // Cập nhật mảng orderItems và tính lại các loại phí
    await _db.collection('reservations').doc(reservationId).update({
      'orderItems': FieldValue.arrayUnion([{
        'itemId': itemId,
        'itemName': itemDoc['name'],
        'quantity': quantity,
        'price': price,
        'subtotal': itemSubtotal
      }]),
      'subtotal': FieldValue.increment(itemSubtotal),
      'serviceCharge': FieldValue.increment(itemSubtotal * 0.1), // Phí phục vụ 10%
    });
  }

  // 3.3.4: Thanh toán & Tích điểm
  Future<void> payReservation(String reservationId, String customerId) async {
    DocumentReference resRef = _db.collection('reservations').doc(reservationId);
    DocumentSnapshot resSnap = await resRef.get();
    DocumentSnapshot custSnap = await _db.collection('customers').doc(customerId).get();

    double subtotal = (resSnap['subtotal'] as num).toDouble();
    double serviceCharge = (resSnap['serviceCharge'] as num).toDouble();
    double totalBeforeDiscount = subtotal + serviceCharge;

    // 1 điểm = 1000đ, giảm tối đa 50% đơn
    int currentPoints = custSnap['loyaltyPoints'] ?? 0;
    double discountValue = currentPoints * 1000.0;
    if (discountValue > (totalBeforeDiscount * 0.5)) discountValue = totalBeforeDiscount * 0.5;

    double finalTotal = totalBeforeDiscount - discountValue;
    int pointsEarned = (finalTotal * 0.01).floor(); // Tích 1%
    int pointsUsed = (discountValue / 1000).floor(); // Trừ điểm đã dùng

    await resRef.update({
      'discount': discountValue,
      'total': finalTotal,
      'paymentStatus': 'paid',
      'status': 'completed',
    });

    await _db.collection('customers').doc(customerId).update({
      'loyaltyPoints': FieldValue.increment(pointsEarned - pointsUsed)
    });
  }
}