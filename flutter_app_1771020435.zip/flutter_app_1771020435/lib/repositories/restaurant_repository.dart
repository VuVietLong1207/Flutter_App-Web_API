import 'package:cloud_firestore/cloud_firestore.dart';

class RestaurantRepository {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  // 3.3.1 Tạo đặt bàn mới [cite: 101, 105]
  Future<void> createReservation(String customerId, Timestamp date, int guests, String? requests) async {
    await _db.collection('reservations').add({
      'customerId': customerId,
      'reservationDate': date,
      'numberOfGuests': guests,
      'specialRequests': requests,
      'status': 'pending', // Mặc định pending [cite: 105]
      'orderItems': [],
      'subtotal': 0.0,
      'serviceCharge': 0.0,
      'total': 0.0,
      'paymentStatus': 'pending',
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  // 3.3.4 Thanh toán: Tính discount & cộng loyaltyPoints [cite: 117, 120, 123]
  Future<void> payReservation(String resId, String method, int currentPoints) async {
    DocumentSnapshot resSnap = await _db.collection('reservations').doc(resId).get();
    double subtotal = resSnap['subtotal'];
    double serviceCharge = resSnap['serviceCharge'];
    double totalBeforeDiscount = subtotal + serviceCharge;

    // Tính discount (tối đa 50% tổng đơn) 
    double discount = currentPoints * 1000.0;
    if (discount > (totalBeforeDiscount * 0.5)) discount = totalBeforeDiscount * 0.5;

    double finalTotal = totalBeforeDiscount - discount;
    int pointsUsed = (discount / 1000).floor();
    int pointsEarned = (finalTotal * 0.01).floor(); // Tích 1% 

    // Cập nhật hóa đơn [cite: 122]
    await _db.collection('reservations').doc(resId).update({
      'discount': discount,
      'total': finalTotal,
      'paymentMethod': method,
      'paymentStatus': 'paid',
      'status': 'completed',
    });

    // Cập nhật điểm khách hàng [cite: 124]
    await _db.collection('customers').doc(resSnap['customerId']).update({
      'loyaltyPoints': FieldValue.increment(pointsEarned - pointsUsed)
    });
  }
  Future<void> addItemToReservation(String resId, String itemId, int quantity) async {
  try {
    DocumentSnapshot itemDoc = await _db.collection('menu_items').doc(itemId).get();
    
    // Kiểm tra món còn hay không 
    if (!itemDoc['isAvailable']) {
      throw Exception("Món này hiện đang hết phục vụ!");
    }

    // Logic tính toán subtotal và update array orderItems [cite: 110, 111]
    // ... code cập nhật Firestore ...
    
  } catch (e) {
    rethrow; // Ném lỗi để UI hiển thị thông báo [cite: 175]
  }
}
}