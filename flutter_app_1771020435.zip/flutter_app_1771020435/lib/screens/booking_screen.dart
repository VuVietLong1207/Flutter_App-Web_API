import 'package:flutter/material.dart';
import '../repositories/reservation_repository.dart';

class BookingScreen extends StatefulWidget {
  final String customerId;
  const BookingScreen({super.key, required this.customerId});

  @override
  State<BookingScreen> createState() => _BookingScreenState();
}

class _BookingScreenState extends State<BookingScreen> {
  DateTime selectedDate = DateTime.now();
  final _guestController = TextEditingController();
  final _reqController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Đặt bàn - 1771020435")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            ListTile(
              title: Text("Ngày đặt: ${selectedDate.day}/${selectedDate.month}/${selectedDate.year}"),
              trailing: const Icon(Icons.calendar_today),
              onTap: () async {
                DateTime? picked = await showDatePicker(
                  context: context, initialDate: selectedDate,
                  firstDate: DateTime.now(), lastDate: DateTime(2026));
                if (picked != null) setState(() => selectedDate = picked);
              },
            ),
            TextField(controller: _guestController, decoration: const InputDecoration(labelText: "Số lượng khách"), keyboardType: TextInputType.number),
            TextField(controller: _reqController, decoration: const InputDecoration(labelText: "Yêu cầu đặc biệt (Ghi chú)")),
            const SizedBox(height: 30),
            ElevatedButton(
              style: ElevatedButton.styleFrom(minimumSize: const Size(double.infinity, 50)),
              onPressed: () async {
                await ReservationRepository().createReservation(
                  widget.customerId, selectedDate, int.parse(_guestController.text), _reqController.text);
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Đặt bàn thành công!")));
              },
              child: const Text("XÁC NHẬN ĐẶT BÀN"),
            )
          ],
        ),
      ),
    );
  }
}