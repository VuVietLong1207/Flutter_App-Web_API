import 'package:flutter/material.dart';
import '../models/menu_item.dart';

class DetailScreen extends StatelessWidget {
  final MenuItem item;
  const DetailScreen({super.key, required this.item});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(item.name),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            // 1. Sửa lỗi gạch đỏ bằng cách thêm errorBuilder
            Container(
              width: double.infinity,
              height: 250,
              color: Colors.grey[200],
              child: Image.network(
                item.imageUrl ?? 'https://via.placeholder.com/300',
                fit: BoxFit.cover,
                // Nếu trình duyệt chặn ảnh (CORS), nó sẽ hiện Icon thay vì chữ đỏ
                errorBuilder: (context, error, stackTrace) {
                  return const Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.fastfood, size: 80, color: Colors.grey),
                      SizedBox(height: 10),
                      Text('Không thể tải hình ảnh', style: TextStyle(color: Colors.grey)),
                    ],
                  );
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    item.name,
                    style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    'Giá: ${item.price} VND',
                    style: const TextStyle(color: Colors.red, fontSize: 20, fontWeight: FontWeight.w500),
                  ),
                  const Divider(),
                  // 2. Hiển thị đúng thời gian từ Database (đã sửa lỗi 0 phút)
                  Row(
                    children: [
                      const Icon(Icons.timer, size: 18, color: Colors.blue),
                      const SizedBox(width: 5),
                      Text('Thời gian chế biến: ${item.preparationTime} phút'),
                    ],
                  ),
                  const SizedBox(height: 10),
                  const Text('Mô tả:', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                  const SizedBox(height: 5),
                  const Text(
                    'Nguyên liệu tươi ngon, chế biến theo công thức truyền thống, đảm bảo vệ sinh an toàn thực phẩm.',
                    style: TextStyle(height: 1.5),
                  ),
                  const SizedBox(height: 30),
                  // 3. Thêm nút Thanh toán để hoàn tất bài thi
                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton.icon(
                      onPressed: () {
                        // Hiển thị thông báo thành công kèm MSSV
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text('Thanh toán thành công món ${item.name}! MSSV: 1771020630'),
                            backgroundColor: Colors.green,
                          ),
                        );
                      },
                      icon: const Icon(Icons.payment),
                      label: const Text('THANH TOÁN TÍCH ĐIỂM', style: TextStyle(fontWeight: FontWeight.bold)),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.orange,
                        foregroundColor: Colors.white,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}