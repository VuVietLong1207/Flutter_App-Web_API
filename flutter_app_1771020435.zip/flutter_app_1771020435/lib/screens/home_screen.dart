import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../repositories/reservation_repository.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Thực đơn - 1771020435")),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection('menu_items').snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
          
          return GridView.builder(
            padding: const EdgeInsets.all(10),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2, 
              childAspectRatio: 0.7,
              crossAxisSpacing: 10,
              mainAxisSpacing: 10,
            ),
            itemCount: snapshot.data!.docs.length,
            itemBuilder: (context, index) {
              var item = snapshot.data!.docs[index];
              bool available = item['isAvailable'] ?? false;

              return Card(
                child: Column(
                  children: [
                    Expanded(
                      child: item['imageUrl'] != null 
                        ? Image.network(item['imageUrl'], fit: BoxFit.cover)
                        : const Icon(Icons.fastfood),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Column(
                        children: [
                          Text(item['name'] ?? '', style: const TextStyle(fontWeight: FontWeight.bold)),
                          Text("${item['price']}đ", style: const TextStyle(color: Colors.red)),
                          ElevatedButton(
                            onPressed: available 
                              ? () => _addFood(context, item.id, item['name']) 
                              : null,
                            child: Text(available ? "Thêm vào đơn" : "Hết món"),
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              );
            },
          );
        },
      ),
    );
  }

  void _addFood(BuildContext context, String itemId, String name) async {
    // Thay 'RES_001' bằng ID đơn thực tế của bạn
    String currentResId = "RES_001"; 
    try {
      await ReservationRepository().addItemToReservation(currentResId, itemId, 1);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Đã thêm $name")));
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    }
  }
}