import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/menu_item.dart'; 
import 'detail_screen.dart'; 

class MenuScreen extends StatefulWidget {
  const MenuScreen({super.key});

  @override
  State<MenuScreen> createState() => _MenuScreenState();
}

class _MenuScreenState extends State<MenuScreen> {
  // Hàm lấy dữ liệu từ API
  Future<List<MenuItem>> fetchMenuItems() async {
    // SỬA TẠI ĐÂY: Dùng đúng endpoint api/MenuItems và cổng 5114
    const url = 'http://localhost:5114/api/MenuItems'; 
    
    try {
      final response = await http.get(Uri.parse(url));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        // Lấy danh sách từ trường 'data' trong JSON trả về
        List list = data['data']; 
        return list.map((json) => MenuItem.fromJson(json)).toList();
      } else {
        throw Exception('Mã lỗi: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Lỗi kết nối: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Thực Đơn - 1771020630'), // AppBar hiển thị MSSV
      ),
      body: FutureBuilder<List<MenuItem>>(
        future: fetchMenuItems(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            // Hiển thị lỗi chi tiết để dễ debug
            return Center(child: Text('Lỗi: ${snapshot.error}'));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(child: Text('Không có món ăn nào trong Database'));
          }

          final items = snapshot.data!;
          return ListView.builder(
            itemCount: items.length,
            itemBuilder: (context, index) {
              final item = items[index];
              return Card(
                margin: const EdgeInsets.all(8.0),
                child: ListTile(
                  leading: Image.network(
                    // Sử dụng placeholder nếu không có ảnh
                    item.imageUrl ?? 'https://via.placeholder.com/150',
                    width: 50, height: 50, fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) => 
                        const Icon(Icons.fastfood, size: 50),
                  ),
                  title: Text(item.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('${item.price} VND'),
                      Row(
                        children: [
                          if (item.isVegetarian) 
                            const Padding(
                              padding: EdgeInsets.only(right: 5),
                              child: Chip(label: Text('Chay', style: TextStyle(fontSize: 10))),
                            ),
                          if (item.isSpicy) 
                            const Chip(label: Text('Cay', style: TextStyle(color: Colors.red, fontSize: 10))),
                        ],
                      ),
                    ],
                  ),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => DetailScreen(item: item)),
                    );
                  },
                ),
              );
            },
          );
        },
      ),
    );
  }
}