import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class MenuScreen extends StatelessWidget {
  const MenuScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        // YÊU CẦU BẮT BUỘC: Thay số này bằng mã sinh viên của bạn [cite: 129]
        title: const Text("Restaurant App - 2151061234"),
        backgroundColor: Colors.orange,
      ),
      body: StreamBuilder<QuerySnapshot>(
        // Real-time Update [cite: 138, 174]
        stream: FirebaseFirestore.instance.collection('menu_items').snapshots(),
        builder: (context, snapshot) {
          if (snapshot.hasError) return const Center(child: Text("Lỗi tải dữ liệu"));
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());

          return GridView.builder(
            padding: const EdgeInsets.all(10),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2, crossAxisSpacing: 10, mainAxisSpacing: 10, childAspectRatio: 0.75,
            ),
            itemCount: snapshot.data!.docs.length,
            itemBuilder: (context, index) {
              var item = snapshot.data!.docs[index];
              return Card(
                elevation: 4,
                child: Column(
                  children: [
                    Expanded(child: Image.network(item['imageUrl'], fit: BoxFit.cover)),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Column(
                        children: [
                          Text(item['name'], style: const TextStyle(fontWeight: FontWeight.bold)),
                          Text("${item['price']} VNĐ", style: const TextStyle(color: Colors.red)),
                          if (!item['isAvailable']) // Badge hết món [cite: 140]
                            const Chip(label: Text("Hết món"), backgroundColor: Colors.grey),
                          Row( // Icon chay, cay [cite: 141]
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              if (item['isVegetarian']) const Icon(Icons.eco, color: Colors.green, size: 20),
                              if (item['isSpicy']) const Icon(Icons.whatshot, color: Colors.red, size: 20),
                            ],
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              );
            },
          );
        },
      ),
    );
  }
}