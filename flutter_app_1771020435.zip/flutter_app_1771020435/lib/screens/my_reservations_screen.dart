import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../repositories/reservation_repository.dart';

class MyReservationsScreen extends StatelessWidget {
  final String customerId;
  const MyReservationsScreen({super.key, required this.customerId});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Đơn của tôi - 1771020435")),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('reservations')
            .where('customerId', isEqualTo: customerId)
            .snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
          
          return ListView.builder(
            itemCount: snapshot.data!.docs.length,
            itemBuilder: (context, index) {
              var res = snapshot.data!.docs[index];
              return Card(
                margin: const EdgeInsets.all(8),
                child: ListTile(
                  title: Text("Ngày: ${(res['reservationDate'] as Timestamp).toDate().toString().split(' ')[0]}"),
                  subtitle: Text("Tổng: ${res['total']}đ - Trạng thái: ${res['status']}"),
                  trailing: res['status'] == 'seated'
                      ? ElevatedButton(
                          onPressed: () => ReservationRepository().payReservation(res.id, customerId),
                          child: const Text("Thanh toán"),
                        )
                      : Text(res['status'].toString().toUpperCase()),
                ),
              );
            },
          );
        },
      ),
    );
  }
}