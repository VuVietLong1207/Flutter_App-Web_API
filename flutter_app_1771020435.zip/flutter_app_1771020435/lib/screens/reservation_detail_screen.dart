import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../repositories/reservation_repository.dart';

class ReservationDetailScreen extends StatelessWidget {
  final String reservationId;
  final String customerId;

  const ReservationDetailScreen({super.key, required this.reservationId, required this.customerId});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Chi tiết đơn - 2151061234")),
      body: StreamBuilder<DocumentSnapshot>(
        stream: FirebaseFirestore.instance.collection('reservations').doc(reservationId).snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
          var data = snapshot.data!.data() as Map<String, dynamic>;
          List items = data['orderItems'] ?? [];

          return Column(
            children: [
              Expanded(
                child: ListView.builder(
                  itemCount: items.length,
                  itemBuilder: (context, i) => ListTile(
                    title: Text("${items[i]['itemName']}"),
                    subtitle: Text("SL: ${items[i]['quantity']}"),
                    trailing: Text("${items[i]['subtotal']}đ"),
                  ),
                ),
              ),
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(color: Colors.orange.shade50, borderRadius: const BorderRadius.vertical(top: Radius.circular(20))),
                child: Column(
                  children: [
                    _priceRow("Tạm tính", "${data['subtotal']}đ"),
                    _priceRow("Phí phục vụ (10%)", "${data['serviceCharge']}đ"),
                    const Divider(),
                    _priceRow("Tổng cộng", "${data['subtotal'] + data['serviceCharge']}đ", isBold: true),
                    const SizedBox(height: 15),
                    if (data['status'] == 'seated') // Chỉ hiện khi khách đang ngồi [cite: 171]
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(minimumSize: const Size(double.infinity, 50), backgroundColor: Colors.orange),
                        onPressed: () => ReservationRepository().payReservation(reservationId, customerId),
                        child: const Text("THANH TOÁN"),
                      )
                  ],
                ),
              )
            ],
          );
        },
      ),
    );
  }

  Widget _priceRow(String label, String value, {bool isBold = false}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: TextStyle(fontWeight: isBold ? FontWeight.bold : FontWeight.normal)),
        Text(value, style: TextStyle(fontWeight: isBold ? FontWeight.bold : FontWeight.normal)),
      ],
    );
  }
}