import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  static const String baseUrl = 'http://localhost:5114/api'; 

  // Logic Đăng nhập [cite: 251]
  Future<Map<String, dynamic>?> login(String email, String password) async {
    final response = await http.post(
      Uri.parse('$baseUrl/auth/login'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'email': email, 'password': password}),
    );

    if (response.statusCode == 200) {
      return jsonDecode(response.body); // Sẽ chứa token và student_id [cite: 99]
    }
    return null;
  }

  // Logic lấy danh sách món ăn [cite: 253]
  Future<List<dynamic>> getMenuItems() async {
    final response = await http.get(Uri.parse('$baseUrl/menu-items'));
    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      return data['data']; // Trả về danh sách món ăn
    }
    return [];
  }
}