package com.example.web_api_1771020435

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
