const express = require('express');
const mysql = require('mysql2');
const jwt = require('jsonwebtoken');
const cors = require('cors'); 
const app = express();

// Cấu hình CORS để cho phép Flutter Web truy cập API 
app.use(cors()); 
app.use(express.json());

// 1. Kết nối Cơ sở dữ liệu (Database Name: db_exam_1771020435)
const db = mysql.createPool({
    host: 'localhost',
    user: 'LongVu',
    password: '@Long2ka51207',
    database: 'db_exam_1771020435' 
});

// 2.1 Đăng ký Customer
app.post('/api/auth/register', (req, res) => {
    const { email, password, full_name, phone_number, address } = req.body;
    const query = 'INSERT INTO customers (email, password, full_name, phone_number, address) VALUES (?, ?, ?, ?, ?)';
    db.execute(query, [email, password, full_name, phone_number, address], (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: "Đăng ký thành công", id: results.insertId });
    });
});

// 2.2 Đăng nhập - Yêu cầu bắt buộc trả về student_id hardcode
app.post('/api/auth/login', (req, res) => {
    const { email, password } = req.body;
    const query = 'SELECT * FROM customers WHERE email = ? AND password = ?';
    db.execute(query, [email, password], (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        
        if (results.length > 0) {
            const user = results[0];
            const token = jwt.sign({ id: user.id }, 'SECRET_KEY', { expiresIn: '24h' });
            
            res.json({
                message: "Đăng nhập thành công",
                token: token,
                user: {
                    id: user.id,
                    email: user.email,
                    full_name: user.full_name
                },
                student_id: "1771020435" // BẮT BUỘC: Mã sinh viên hardcode
            });
        } else {
            res.status(401).json({ message: "Email hoặc mật khẩu không chính xác" });
        }
    });
});

// 4.1 Lấy danh sách Menu Items
app.get('/api/menu-items', (req, res) => {
    db.query('SELECT * FROM menu_items WHERE is_available = true', (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results);
    });
});

// 5.1 Đặt Bàn (Tạo Reservation)
app.post('/api/reservations', (req, res) => {
    const { customer_id, reservation_date, number_of_guests } = req.body;
    const resNumber = `RES-${Date.now()}`; // Mã đặt bàn tự sinh
    
    const query = 'INSERT INTO reservations (customer_id, reservation_number, reservation_date, number_of_guests, status) VALUES (?, ?, ?, ?, "pending")';
    db.execute(query, [customer_id, resNumber, reservation_date, number_of_guests], (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ 
            message: "Đặt bàn thành công", 
            reservation_id: results.insertId, 
            reservation_number: resNumber 
        });
    });
});

// 5.6 Thanh toán & Tính Loyalty Points (1% tổng hóa đơn)
app.post('/api/reservations/:id/pay', (req, res) => {
    const resId = req.params.id;
    const { total_amount, customer_id } = req.body;
    
    // Tính điểm thưởng: 1% tổng hóa đơn
    const loyaltyPoints = Math.floor(total_amount * 0.01); 

    db.getConnection((err, conn) => {
        if (err) return res.status(500).json({ error: err.message });
        
        conn.beginTransaction((err) => {
            if (err) return res.status(500).json({ error: err.message });

            // 1. Cập nhật trạng thái đặt bàn
            conn.query('UPDATE reservations SET status = "completed", payment_status = "paid" WHERE id = ?', [resId], (err) => {
                if (err) return conn.rollback(() => res.status(500).json(err));

                // 2. Cộng điểm thưởng cho khách hàng (1% total)
                conn.query('UPDATE customers SET loyalty_points = loyalty_points + ? WHERE id = ?', [loyaltyPoints, customer_id], (err) => {
                    if (err) return conn.rollback(() => res.status(500).json(err));

                    conn.commit((err) => {
                        if (err) return conn.rollback(() => res.status(500).json(err));
                        res.json({ message: "Thanh toán thành công", added_points: loyaltyPoints });
                    });
                });
            });
        });
    });
});

// Khởi động Server trên cổng 3000
const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Server đang chạy tại: http://localhost:${PORT}`);
});