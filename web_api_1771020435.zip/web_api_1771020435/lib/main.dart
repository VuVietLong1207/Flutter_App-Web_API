import 'package:flutter/material.dart';
// Sử dụng đường dẫn tương đối để tránh lỗi tên package
import 'screen/login_screen.dart'; 

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Restaurant App',
      // BỎ từ khóa const ở đây
      home: LoginScreen(), 
    );
  }
}