class MenuItem {
  final int id;
  final String name;
  final String? description;
  final double price;
  final String? imageUrl;
  final int isVegetarian;
  final int isSpicy;
  final int preparationTime;

  MenuItem({
    required this.id,
    required this.name,
    this.description,
    required this.price,
    this.imageUrl,
    required this.isVegetarian,
    required this.isSpicy,
    required this.preparationTime,
  });

  factory MenuItem.fromJson(Map<String, dynamic> json) {
    return MenuItem(
      id: json['id'],
      name: json['name'],
      description: json['description'],
      price: double.parse(json['price'].toString()),
      imageUrl: json['image_url'],
      isVegetarian: json['is_vegetarian'] ?? 0,
      isSpicy: json['is_spicy'] ?? 0,
      preparationTime: json['preparation_time'] ?? 0,
    );
  }
}