import 'package:flutter/material.dart';

class DetailScreen extends StatelessWidget {
  final dynamic item; // Nhận dữ liệu món ăn từ MenuScreen

  const DetailScreen({super.key, required this.item});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(item['name']),
        backgroundColor: Colors.orange,
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Hình ảnh món ăn
            Image.network(
              item['image_url'] ?? 'https://via.placeholder.com/400x250',
              width: double.infinity,
              height: 250,
              fit: BoxFit.cover,
            ),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    item['name'],
                    style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    "${item['price']} VND",
                    style: const TextStyle(fontSize: 20, color: Colors.redAccent, fontWeight: FontWeight.w600),
                  ),
                  const Divider(height: 30),
                  const Text("Mô tả:", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  Text(item['description'] ?? "Không có mô tả cho món ăn này."),
                  const SizedBox(height: 20),
                  // Thông tin thêm theo yêu cầu đề bài
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      _buildInfoChip(Icons.timer, "${item['preparation_time']} phút"),
                      if (item['is_vegetarian'] == 1) _buildInfoChip(Icons.eco, "Món chay"),
                      if (item['is_spicy'] == 1) _buildInfoChip(Icons.whatshot, "Món cay", color: Colors.red),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoChip(IconData icon, String label, {Color color = Colors.grey}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color),
      ),
      child: Row(
        children: [
          Icon(icon, size: 18, color: color),
          const SizedBox(width: 4),
          Text(label, style: TextStyle(color: color)),
        ],
      ),
    );
  }
}