import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'detail_screen.dart'; // Đảm bảo bạn đã tạo file này trong cùng thư mục

class MenuScreen extends StatefulWidget {
  const MenuScreen({super.key});

  @override
  State<MenuScreen> createState() => _MenuScreenState();
}

class _MenuScreenState extends State<MenuScreen> {
  // ĐỊNH NGHĨA HÀM fetchMenu Ở ĐÂY
  Future<List<dynamic>> fetchMenu() async {
    try {
      // Thay localhost thành 10.0.2.2 nếu dùng giả lập Android
      final response = await http.get(Uri.parse('http://localhost:3000/api/menu-items'));
      
      if (response.statusCode == 200) {
        return json.decode(response.body);
      } else {
        throw Exception('Không thể tải menu');
      }
    } catch (e) {
      throw Exception('Lỗi kết nối: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Thực Đơn Nhà Hàng"),
        backgroundColor: Colors.orange,
      ),
      body: FutureBuilder<List<dynamic>>(
        future: fetchMenu(), // Gọi hàm đã định nghĩa ở trên
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text("Lỗi: ${snapshot.error}"));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(child: Text("Không có món ăn nào"));
          }

          return ListView.builder(
            itemCount: snapshot.data!.length,
            itemBuilder: (context, index) {
              var item = snapshot.data![index];
              return Card(
                margin: const EdgeInsets.all(8.0),
                child: ListTile(
                  leading: Image.network(
                    item['image_url'] ?? 'https://via.placeholder.com/150',
                    width: 60,
                    fit: BoxFit.cover,
                  ),
                  title: Text(item['name'], style: const TextStyle(fontWeight: FontWeight.bold)),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("${item['price']} VND"),
                      Row(
                        children: [
                          // Hiển thị món chay/mặn [cite: 255]
                          if (item['is_vegetarian'] == 1)
                            const Icon(Icons.eco, color: Colors.green, size: 16),
                          // Hiển thị món cay [cite: 255]
                          if (item['is_spicy'] == 1)
                            const Icon(Icons.whatshot, color: Colors.red, size: 16),
                        ],
                      )
                    ],
                  ),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => DetailScreen(item: item),
                      ),
                    );
                  },
                ),
              );
            },
          );
        },
      ),
    );
  }
}